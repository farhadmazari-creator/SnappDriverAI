package com.farhadmazari.snappdriverai

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale

class SnappAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastSignature = ""
    private var overlay: FloatingOverlay? = null
    private val targetPackage = "cab.snapp.driver"
    private val analyzeRunnable = Runnable { analyzeCurrentWindow() }
    private val updateRunnable = object : Runnable {
        override fun run() {
            UpdateChecker.maybeCheck(this@SnappAccessibilityService)
            handler.postDelayed(this, 6L * 60 * 60 * 1000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_SCROLLED
            flags = flags or android.accessibilityservice.AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    android.accessibilityservice.AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        }
        UpdateChecker.maybeCheck(this)
        handler.post(updateRunnable)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName?.toString() != targetPackage) return
        handler.removeCallbacks(analyzeRunnable)
        handler.postDelayed(analyzeRunnable, 300)
    }

    private fun analyzeCurrentWindow() {
        val root = rootInActiveWindow ?: return
        val lines = ArrayList<String>()
        collect(root, lines)
        if (lines.isEmpty()) return

        val signature = lines.joinToString("|")
        if (signature == lastSignature) return
        lastSignature = signature

        val trip = TripParser.parse(lines)
        if (!looksLikeOffer(trip, lines)) return

        val p = getSharedPreferences("settings", MODE_PRIVATE)
        val minFare = p.getString("minFare", "100000")?.toLongOrNull() ?: 100000L
        val minKm = p.getString("minKm", "12000")?.toDoubleOrNull() ?: 12000.0
        val minHour = p.getString("minHour", "150000")?.toDoubleOrNull() ?: 150000.0
        val areas = p.getString("areas", "")?.split(",")?.map { it.trim() } ?: emptyList()
        val result = TripEvaluator.evaluate(trip, minFare, minKm, minHour, areas)
        showOverlay(result)
    }

    private fun looksLikeOffer(trip: TripData, lines: List<String>): Boolean {
        val all = lines.joinToString(" ").lowercase()
        val snappSignals = listOf("مقصد", "مبدا", "مبدأ", "کرایه", "تومان", "کیلومتر", "مسافت", "دقیقه")
        val signals = snappSignals.count { all.contains(it) }
        return signals >= 2 || trip.fare != null || trip.distanceKm != null
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<String>) {
        node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(out::add)
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(out::add)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let {
                collect(it, out)
                it.recycle()
            }
        }
    }

    private fun showOverlay(score: TripScore) {
        // Only the compact traffic-light circle stays visible across all screens.
        // The detailed analysis remains in the app; the overlay is intentionally minimal.
        overlay?.hide()
        overlay = FloatingOverlay(this).also { it.show(score.verdict) }
    }

    override fun onInterrupt() {
        overlay?.hide()
        overlay = null
    }

    override fun onDestroy() {
        handler.removeCallbacks(updateRunnable)
        onInterrupt()
        super.onDestroy()
    }
}
