package com.farhadmazari.snappdriverai

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max

data class TripData(
    val fare: Long? = null,
    val distanceKm: Double? = null,
    val durationMin: Double? = null,
    val origin: String? = null,
    val destination: String? = null,
    val rawText: String = ""
)

data class TripScore(
    val score: Int,
    val verdict: String,
    val reasons: List<String>
)

object TripParser {
    private val persianDigits = "۰۱۲۳۴۵۶۷۸۹"
    private val arabicDigits = "٠١٢٣٤٥٦٧٨٩"

    fun normalizeDigits(s: String): String {
        val out = StringBuilder()
        for (c in s) {
            val p = persianDigits.indexOf(c)
            val a = arabicDigits.indexOf(c)
            out.append(
                when {
                    p >= 0 -> ('0'.code + p).toChar()
                    a >= 0 -> ('0'.code + a).toChar()
                    c == '٬' || c == '،' -> ','
                    c == '٫' -> '.'
                    else -> c
                }
            )
        }
        return out.toString()
    }

    private fun number(s: String): Double? {
        val x = normalizeDigits(s).replace(" ", "").replace(",", "")
        return x.toDoubleOrNull()
    }

    private fun firstNumberAfter(line: String, keys: List<String>): Double? {
        val n = normalizeDigits(line)
        val lower = n.lowercase()
        for (key in keys) {
            val i = lower.indexOf(key.lowercase())
            if (i >= 0) {
                val tail = n.substring(i + key.length)
                val m = Regex("""([0-9]+(?:[.,][0-9]+)?)""").find(tail)
                if (m != null) return number(m.groupValues[1])
            }
        }
        return null
    }

    fun parse(lines: List<String>): TripData {
        val clean = lines.map { it.trim() }.filter { it.isNotBlank() }
        val raw = clean.joinToString("\n")
        val normalized = normalizeDigits(raw)

        var fare: Long? = null
        Regex("""([0-9][0-9,.\s]{1,20})\s*(?:تومان|تومن|ریال)""")
            .findAll(normalized).forEach { m ->
                val v = number(m.groupValues[1])
                if (v != null && v >= 1000) {
                    val candidate = if (m.groupValues[0].contains("ریال")) v / 10.0 else v
                    fare = max(fare ?: 0L, candidate.toLong())
                }
            }

        if (fare == null) {
            val f = firstNumberAfter(normalized, listOf("کرایه", "مبلغ", "درآمد", "قیمت", "دریافتی"))
            if (f != null && f >= 1000) fare = f.toLong()
        }

        val distance = Regex("""([0-9]+(?:[.,][0-9]+)?)\s*(?:کیلومتر|km|ک\.م)""", RegexOption.IGNORE_CASE)
            .find(normalized)?.groupValues?.get(1)?.let(::number)
            ?: firstNumberAfter(normalized, listOf("مسافت", "فاصله"))

        val duration = Regex("""([0-9]+(?:[.,][0-9]+)?)\s*(?:دقیقه|دقیقه‌|min)""", RegexOption.IGNORE_CASE)
            .find(normalized)?.groupValues?.get(1)?.let(::number)
            ?: firstNumberAfter(normalized, listOf("مدت", "زمان"))

        var origin: String? = null
        var destination: String? = null
        for (line in clean) {
            val n = normalizeDigits(line)
            val low = n.lowercase()
            if (origin == null) {
                val idx = maxOf(low.indexOf("مبدأ"), low.indexOf("مبدا"))
                if (idx >= 0) {
                    origin = n.substring(idx).substringAfter(":").trim().ifBlank { null }
                }
            }
            if (destination == null) {
                val idx = low.indexOf("مقصد")
                if (idx >= 0) {
                    destination = n.substring(idx).substringAfter(":").trim().ifBlank { null }
                }
            }
        }

        return TripData(fare, distance, duration, origin, destination, raw)
    }
}

object TripEvaluator {
    fun evaluate(trip: TripData, minFare: Long, minPerKm: Double, minHourly: Double, blockedAreas: List<String> = emptyList()): TripScore {
        val reasons = mutableListOf<String>()
        var points = 100

        val destinationText = listOfNotNull(trip.destination, trip.origin).joinToString(" ")
        blockedAreas.firstOrNull { it.isNotBlank() && destinationText.contains(it.trim(), ignoreCase = true) }?.let {
            points -= 60
            reasons += "مقصد/مبدأ در محدوده فیلترشده: $it"
        }

        trip.fare?.let {
            if (it < minFare) {
                points -= 25
                reasons += "مبلغ کمتر از حداقل تعیین‌شده"
            }
        } ?: run { points -= 15; reasons += "مبلغ سفر از صفحه خوانده نشد" }

        trip.distanceKm?.let {
            if (it > 0 && trip.fare != null) {
                val perKm = trip.fare / it
                if (perKm < minPerKm) {
                    points -= 25
                    reasons += "درآمد هر کیلومتر پایین است (${format(perKm)} تومان)"
                }
            }
        } ?: run { points -= 10; reasons += "مسافت خوانده نشد" }

        trip.durationMin?.let {
            if (it > 0 && trip.fare != null) {
                val hourly = trip.fare * 60.0 / it
                if (hourly < minHourly) {
                    points -= 20
                    reasons += "درآمد ساعتی پایین است (${format(hourly)} تومان)"
                }
            }
        }

        val score = points.coerceIn(0, 100)
        val verdict = when {
            score >= 75 -> "مناسب"
            score >= 50 -> "مرزی"
            else -> "نامناسب"
        }
        return TripScore(score, verdict, reasons)
    }

    private fun format(v: Double): String =
        NumberFormat.getNumberInstance(Locale.US).format(v.toLong())
}
