package com.farhadmazari.snappdriverai

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

class FloatingOverlay(private val context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0

    /** Compact always-on-top status indicator: green=good, yellow=borderline, red=bad. */
    fun show(verdict: String) {
        val size = (46 * context.resources.displayMetrics.density).toInt()
        val circle = View(context).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(when {
                    verdict.contains("مناسب") && !verdict.contains("نامناسب") -> Color.rgb(34, 197, 94)
                    verdict.contains("مرزی") -> Color.rgb(245, 183, 45)
                    else -> Color.rgb(239, 68, 68)
                })
                setStroke((2 * context.resources.displayMetrics.density).toInt(), Color.WHITE)
            }
            contentDescription = "وضعیت سفر: $verdict"
        }

        val p = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 12
            y = 110
        }

        circle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = p.x; startY = p.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (event.rawX - downX).toInt()
                    p.y = startY + (event.rawY - downY).toInt()
                    runCatching { wm.updateViewLayout(circle, p) }
                    true
                }
                MotionEvent.ACTION_UP -> true
                else -> true
            }
        }

        hide()
        runCatching { wm.addView(circle, p); view = circle; params = p }
    }

    fun hide() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        params = null
    }
}
