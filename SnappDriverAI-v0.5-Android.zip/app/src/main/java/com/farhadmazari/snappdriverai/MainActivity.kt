package com.farhadmazari.snappdriverai

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : android.app.Activity() {
    private lateinit var status: TextView
    private lateinit var minFare: EditText
    private lateinit var minKm: EditText
    private lateinit var minHour: EditText
    private lateinit var areas: EditText
    private lateinit var interval: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        UpdateChecker.maybeCheck(this, force = true)
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 28, 32, 28)
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "Snapp Driver AI 0.5"
            textSize = 25f
            setTextColor(Color.rgb(20, 20, 20))
        }, lp())

        root.addView(TextView(this).apply {
            text = "تحلیل خودکار پیشنهاد سفر + پنل شناور + بروزرسانی دوره‌ای"
            textSize = 16f
            setPadding(0, 8, 0, 18)
        }, lp())

        status = TextView(this).apply {
            textSize = 16f
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(240, 248, 240))
        }
        root.addView(status, lp())

        root.addView(Button(this).apply {
            text = "فعال‌کردن دسترسی خواندن خودکار"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, lp())

        root.addView(section("حداقل‌های ارزیابی"), lp())
        minFare = input("حداقل مبلغ سفر (تومان)", "100000")
        minKm = input("حداقل درآمد هر کیلومتر (تومان)", "12000")
        minHour = input("حداقل درآمد ساعتی (تومان)", "150000")
        root.addView(minFare, lp()); root.addView(minKm, lp()); root.addView(minHour, lp())

        root.addView(section("مناطق نامطلوب"), lp())
        root.addView(TextView(this).apply {
            text = "هر منطقه را با ویرگول جدا کن. هر زمان خواستی می‌توانی مورد جدید اضافه یا حذف کنی."
            textSize = 13f
        }, lp())
        areas = EditText(this).apply {
            hint = "مثلاً: شهرک امام هادی, پنج تن, ..."
            minLines = 4
            gravity = android.view.Gravity.TOP
            setTextSize(15f)
        }
        root.addView(areas, lp())

        root.addView(section("پنل شناور"), lp())
        root.addView(TextView(this).apply {
            text = "پنل نتیجه روی سایر برنامه‌ها هم باقی می‌ماند و قابل جابه‌جایی است؛ دکمه × آن را می‌بندد."
            textSize = 13f
        }, lp())

        root.addView(section("بروزرسانی برنامه"), lp())
        root.addView(TextView(this).apply {
            text = "برنامه به‌صورت دوره‌ای انتشارهای جدید GitHub را بررسی می‌کند. نصب نسخه جدید به‌دلیل محدودیت امنیتی اندروید با تأیید شما انجام می‌شود."
            textSize = 13f
        }, lp())
        interval = Spinner(this)
        interval.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("هر روز", "هر هفته"))
        root.addView(interval, lp())

        root.addView(Button(this).apply {
            text = "ذخیره تنظیمات"
            setOnClickListener {
                saveSettings()
                Toast.makeText(this@MainActivity, "تنظیمات ذخیره شد", Toast.LENGTH_SHORT).show()
            }
        }, lp())

        root.addView(Button(this).apply {
            text = "همین الآن بررسی بروزرسانی"
            setOnClickListener { UpdateChecker.maybeCheck(this@MainActivity, force = true) }
        }, lp())

        root.addView(TextView(this).apply {
            text = "نسخه 0.5: اطلاعات سفر از رابط قابل‌دسترسی اسنپ خوانده می‌شود. برنامه خودش سفر را قبول/رد نمی‌کند."
            textSize = 13f
            setPadding(0, 18, 0, 0)
        }, lp())

        setContentView(ScrollView(this).apply { addView(root) })
        loadSettings()
    }

    private fun section(s: String) = TextView(this).apply {
        text = s
        textSize = 18f
        setPadding(0, 20, 0, 8)
    }

    private fun input(hint: String, value: String): EditText = EditText(this).apply {
        this.hint = hint
        setText(value)
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
    }

    private fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun prefs() = getSharedPreferences("settings", Context.MODE_PRIVATE)

    private fun loadSettings() {
        minFare.setText(prefs().getString("minFare", "100000"))
        minKm.setText(prefs().getString("minKm", "12000"))
        minHour.setText(prefs().getString("minHour", "150000"))
        areas.setText(prefs().getString("areas", "شهرک امام هادی,قطعه ساختمان,پنج تن,درویشی سیس آباد,کشاورز,حر پایین شهر"))
        interval.setSelection(if (prefs().getInt("updateIntervalDays", 7) == 1) 0 else 1)
    }

    private fun saveSettings() {
        prefs().edit()
            .putString("minFare", minFare.text.toString())
            .putString("minKm", minKm.text.toString())
            .putString("minHour", minHour.text.toString())
            .putString("areas", areas.text.toString())
            .putInt("updateIntervalDays", if (interval.selectedItemPosition == 0) 1 else 7)
            .apply()
    }

    private fun refreshStatus() {
        val enabled = getSystemService(android.view.accessibility.AccessibilityManager::class.java)
            ?.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            ?.any { it.resolveInfo.serviceInfo.packageName == packageName } == true
        status.text = if (enabled) "وضعیت: فعال — اطلاعات پیشنهاد سفر اسنپ خودکار خوانده می‌شود و پنل شناور نمایش داده می‌شود."
        else "وضعیت: غیرفعال — دکمه بالا را بزن و سرویس Snapp Driver AI را روشن کن."
    }
}
