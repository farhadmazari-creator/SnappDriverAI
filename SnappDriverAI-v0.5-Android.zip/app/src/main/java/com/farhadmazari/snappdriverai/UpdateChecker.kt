package com.farhadmazari.snappdriverai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object UpdateChecker {
    private const val PREFS = "settings"
    private const val LAST_CHECK = "lastUpdateCheck"
    private const val REPO = "farhadmazari-creator/SnappDriverAI"
    private const val API = "https://api.github.com/repos/$REPO/releases/latest"
    private const val RELEASES = "https://github.com/$REPO/releases"
    private val executor = Executors.newSingleThreadExecutor()

    fun maybeCheck(context: Context, force: Boolean = false) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val last = prefs.getLong(LAST_CHECK, 0L)
        val days = prefs.getInt("updateIntervalDays", 7).coerceIn(1, 7)
        val interval = days.toLong() * 24 * 60 * 60 * 1000
        if (!force && now - last < interval) return
        prefs.edit().putLong(LAST_CHECK, now).apply()

        executor.execute {
            runCatching {
                val conn = URL(API).openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.setRequestProperty("Accept", "application/vnd.github+json")
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val json = JSONObject(text)
                val tag = json.optString("tag_name")
                val current = context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0.0.0"
                if (isNewer(tag, current)) {
                    val url = json.optString("html_url", RELEASES)
                    context.mainExecutor.execute {
                        Toast.makeText(context, "نسخه جدید Snapp Driver AI منتشر شده است؛ برای بروزرسانی وارد بخش انتشارها شوید.", Toast.LENGTH_LONG).show()
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
            }
        }
    }

    private fun isNewer(remote: String, local: String): Boolean {
        fun parts(v: String): List<Int> = v.removePrefix("v").split(".").map { it.takeWhile(Char::isDigit).toIntOrNull() ?: 0 }
        val r = parts(remote)
        val l = parts(local)
        for (i in 0 until maxOf(r.size, l.size)) {
            val a = r.getOrElse(i) { 0 }
            val b = l.getOrElse(i) { 0 }
            if (a != b) return a > b
        }
        return false
    }
}
