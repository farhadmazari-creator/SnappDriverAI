package com.snappdriverai.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.TextView
import android.widget.LinearLayout

class OverlayService : Service() {
    private var window: WindowManager? = null
    private var view: View? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) return START_NOT_STICKY
        if (view != null) return START_STICKY

        window = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 12)
            setBackgroundResource(com.snappdriverai.app.R.drawable.panel_bg)
        }
        box.addView(TextView(this).apply {
            text = "🟢 Snapp Driver AI"
            textSize = 16f
            setTextColor(Color.DKGRAY)
        })
        box.addView(TextView(this).apply {
            text = "برای تحلیل سفر، اطلاعات سفر را در برنامه وارد کنید."
            textSize = 12f
            setTextColor(Color.DKGRAY)
        })

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.END
        params.x = 12
        params.y = 160

        window!!.addView(box, params)
        view = box
        return START_STICKY
    }

    override fun onDestroy() {
        view?.let { window?.removeView(it) }
        view = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
