package com.snappdriverai.app

data class Trip(
    val fare: Double,
    val pickupKm: Double,
    val tripKm: Double,
    val etaMin: Double,
    val pickupEtaMin: Double,
    val traffic: Double,
    val destinationQuality: Double,
    val returnProbability: Double,
    val demand: Double,
    val temperatureC: Double,
    val dayOfWeek: Int,
    val hour: Double,
    val destinationType: DestinationType = DestinationType.NORMAL
)

enum class DestinationType { NORMAL, HOME, PERSONAL, INTERCITY, KASHMAR }
