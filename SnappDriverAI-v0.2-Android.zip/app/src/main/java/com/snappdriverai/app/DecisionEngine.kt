package com.snappdriverai.app

import kotlin.math.max
import kotlin.math.min

data class Decision(
    val score: Int,
    val decision: String,
    val grossHourly: Double,
    val netHourly: Double,
    val vehicleCost: Double,
    val totalKm: Double,
    val totalMin: Double,
    val reasons: List<String>
)

object DecisionEngine {
    // Initial conservative values. They are editable later and should be calibrated
    // from the driver's real trip history.
    private const val FUEL_TOMAN_PER_KM = 1800.0
    private const val WEAR_TOMAN_PER_KM = 2600.0
    private const val TARGET_NET_HOURLY = 250000.0

    private fun clamp(x: Double) = max(0.0, min(1.0, x))

    private fun timeScore(day: Int, hour: Double): Double {
        // 0=Saturday ... 6=Friday. Initial summer model for Mashhad.
        return when {
            day <= 3 && hour in 6.0..8.5 -> 1.0
            day <= 3 && hour in 18.0..21.5 -> 1.0
            day <= 3 && hour in 21.5..23.5 -> 0.78
            day == 4 && hour in 19.0..23.5 -> 1.0
            day == 5 && hour in 19.0..23.5 -> 1.0
            day == 6 && hour in 19.0..23.5 -> 1.0
            day <= 3 && hour in 8.5..11.5 -> 0.58
            else -> 0.30
        }
    }

    private fun heatPenalty(temp: Double): Double = when {
        temp <= 25 -> 0.0
        temp <= 30 -> (temp - 25) / 5 * .25
        temp <= 35 -> .25 + (temp - 30) / 5 * .45
        else -> .70 + min((temp - 35) / 10, .30)
    }

    fun analyze(t: Trip): Decision {
        val totalKm = t.pickupKm + t.tripKm
        val totalMin = max(1.0, t.pickupEtaMin + t.etaMin)
        val cost = totalKm * (FUEL_TOMAN_PER_KM + WEAR_TOMAN_PER_KM)
        val grossHourly = t.fare / totalMin * 60.0
        val net = max(0.0, t.fare - cost)
        var netHourly = net / totalMin * 60.0

        var economics = clamp(netHourly / TARGET_NET_HOURLY)
        economics = clamp(economics - clamp(t.pickupEtaMin / 20.0) * .20)

        val traffic = 1.0 - clamp(t.traffic)
        val destination = clamp(t.destinationQuality)
        val returnP = clamp(t.returnProbability)
        val time = timeScore(t.dayOfWeek, t.hour)
        val heat = heatPenalty(t.temperatureC)

        var raw =
            economics * 30 +
            clamp(netHourly / TARGET_NET_HOURLY) * 20 +
            traffic * 12 +
            destination * 12 +
            returnP * 8 +
            time * 8 +
            (1 - heat) * 5

        // Personal destination value: bounded so a personal reason cannot turn
        // a clearly uneconomic trip into an automatic accept.
        when (t.destinationType) {
            DestinationType.HOME -> raw += 10
            DestinationType.PERSONAL -> raw += 7
            DestinationType.KASHMAR -> raw += 10
            DestinationType.INTERCITY -> {
                raw += if (returnP >= .65) 5 else -3
            }
            DestinationType.NORMAL -> Unit
        }

        if (netHourly < 90000) raw -= 18
        else if (netHourly < 130000) raw -= 8
        if (t.pickupEtaMin > 12) raw -= 6
        if (t.traffic > .85) raw -= 8
        if (t.demand < .25 && returnP < .35) raw -= 8

        // Intercity safety/economics guardrail.
        if (t.destinationType == DestinationType.INTERCITY || t.destinationType == DestinationType.KASHMAR) {
            if (t.tripKm > 180 && returnP < .40) raw -= 8
            if (t.etaMin > 180) raw -= 5
        }

        val score = clamp(raw).let { (it * 100).toInt() }
        val decision = when {
            score >= 80 -> "ACCEPT"
            score >= 60 -> "REVIEW"
            else -> "REJECT"
        }

        val reasons = mutableListOf<String>()
        if (netHourly >= 180000) reasons += "سود ساعتی مناسب"
        if (netHourly < 120000) reasons += "سود ساعتی پایین"
        if (t.pickupEtaMin <= 5) reasons += "مبدأ نزدیک"
        if (t.pickupEtaMin > 12) reasons += "مبدأ دور"
        if (t.traffic < .35) reasons += "ترافیک روان"
        if (t.traffic > .75) reasons += "ترافیک سنگین"
        if (destination >= .75) reasons += "مقصد پرتردد"
        if (destination < .35) reasons += "مقصد کم‌تقاضا"
        if (returnP >= .75) reasons += "احتمال سفر بعدی بالا"
        if (returnP < .35) reasons += "احتمال بیکاری بعدی"
        if (time >= .85) reasons += "بازه طلایی"
        if (heat > .65) reasons += "گرمای شدید"
        if (t.destinationType == DestinationType.KASHMAR) reasons += "ارزش شخصی کاشمر"
        if (t.destinationType == DestinationType.HOME) reasons += "نزدیک شدن به خانه"

        return Decision(
            score = score,
            decision = decision,
            grossHourly = grossHourly,
            netHourly = netHourly,
            vehicleCost = cost,
            totalKm = totalKm,
            totalMin = totalMin,
            reasons = reasons.distinct()
        )
    }
}
