package com.snappdriverai.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private fun num(id: Int): Double = findViewById<EditText>(id).text.toString().toDoubleOrNull() ?: 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnAnalyze).setOnClickListener {
            val trip = Trip(
                fare = num(R.id.fare),
                pickupKm = num(R.id.pickupKm),
                tripKm = num(R.id.tripKm),
                etaMin = num(R.id.etaMin),
                pickupEtaMin = num(R.id.pickupEtaMin),
                traffic = num(R.id.traffic),
                destinationQuality = num(R.id.destinationQuality),
                returnProbability = num(R.id.returnProbability),
                demand = num(R.id.demand),
                temperatureC = num(R.id.temperature),
                dayOfWeek = findViewById<Spinner>(R.id.day).selectedItemPosition,
                hour = num(R.id.hour),
                destinationType = when(findViewById<Spinner>(R.id.destinationType).selectedItemPosition) {
                    1 -> DestinationType.HOME
                    2 -> DestinationType.PERSONAL
                    3 -> DestinationType.INTERCITY
                    4 -> DestinationType.KASHMAR
                    else -> DestinationType.NORMAL
                }
            )
            val d = DecisionEngine.analyze(trip)
            val title = when(d.decision) {
                "ACCEPT" -> "🟢 قبول"
                "REVIEW" -> "🟡 بررسی دستی"
                else -> "🔴 رد"
            }
            findViewById<TextView>(R.id.result).text =
                "$title\nامتیاز: ${d.score}/100\n" +
                "سود تقریبی ساعتی: ${d.netHourly.roundToInt()} تومان\n" +
                "کل مسافت: ${"%.1f".format(d.totalKm)} km\n" +
                "کل زمان: ${"%.0f".format(d.totalMin)} دقیقه\n\n" +
                d.reasons.joinToString(" • ")
        }

        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "پنل شناور فعال شد", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
