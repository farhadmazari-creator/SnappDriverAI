# Snapp Driver AI v0.2

نسخه Android/Kotlin قابل Build برای پروژه تصمیم‌یار راننده.

## مشخصات هدف
- POCO X3 Pro
- رابط فارسی/RTL
- Home Base: شهرک فرهنگیان، طرقبه
- مقصد شخصی مهم: کاشمر
- پشتیبانی مفهومی از شهری، حومه و بین‌شهری
- موتور امتیازدهی اقتصادی
- پنل شناور پایه
- GitHub Actions برای ساخت APK

## Build ابری
Workflow در `.github/workflows/build-apk.yml` قرار دارد.
پس از Push روی `main`، GitHub Actions APK را می‌سازد و به‌عنوان Artifact منتشر می‌کند.

## نکته
این نسخه «هسته حرفه‌ای v0.2» است، نه اتصال خودکار به اپ اسنپ. دریافت خودکار اطلاعات سفر، سرویس نقشه/ترافیک و مدل یادگیری شخصی در مراحل بعدی به‌صورت Provider/Module اضافه می‌شوند.

## نصب
پس از موفقیت Workflow:
Actions → Build Android APK → Artifacts → SnappDriverAI-debug
فایل ZIP را دانلود و APK داخل آن را روی گوشی نصب کنید.
